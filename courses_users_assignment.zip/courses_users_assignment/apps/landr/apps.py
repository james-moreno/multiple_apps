from django.apps import AppConfig


class LandrConfig(AppConfig):
    name = 'landr'
